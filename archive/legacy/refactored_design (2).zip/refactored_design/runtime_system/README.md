# MiniRISC-16 Runtime System + Snake V2

这是完全独立于原 RTL、`calculator_system` 和已验证 `snake_system` 的新版工程。旧目录没有被修改。本目录包含可综合 RTL、1024 字程序镜像、UART 程序加载器、Snake V2、testbench、Vivado 工程脚本、约束、报告和 bitstream。

## 已实现功能

- 程序空间由 `256×16` 扩充为 `1024×16`，PC 由 8 位扩充为 10 位。
- 原 `JUMP/JZ` 保持兼容，定义为当前 256 字页内跳转。
- opcode `0xF` 新增 `JMPA addr10`，可跨 4 个程序页绝对跳转。
- 程序存储器为可写 `1K×16` 分布式 RAM，配置后默认含 Snake V2。
- SW7=1 时 CPU 停止并进入 UART Loader；SW7=0 时 CPU 从 `0x000` 运行。
- `upload_program.ps1` 可通过 J8/COM3 上传新的 1024 字程序，不重新生成 bitstream。
- Snake V2 增加固定障碍物、随得分加速、高分记录、72 字节诊断帧和终端状态显示。
- 保留自碰撞、墙碰撞、食物、增长、暂停、方向保护和硬件复位。

## 顶层结构

```text
runtime_board_top
├─ reset_conditioner
├─ runtime_soc
│  ├─ runtime_program_memory      1024×16，可由 Loader 写入
│  ├─ program_loader             UART 二进制加载器
│  ├─ cpu_core
│  │  ├─ controller
│  │  └─ datapath
│  ├─ data_memory                256×16
│  └─ snake_peripheral_subsystem
│     ├─ uart_port
│     ├─ tick_timer
│     ├─ lfsr8
│     ├─ display_registers
│     ├─ led8
│     ├─ scratchpad16
│     └─ io_decoder
└─ seven_segment8_driver
```

Vivado 综合顶层为 `runtime_board_top`，器件为 `xc7z020clg484-1`。

## ISA 地址扩充

```text
JUMP target8 : PC_next = {PC[9:8], target8}
JZ target8   : Z=1 时 PC_next = {PC[9:8], target8}
JMPA addr10  : PC_next = addr10
```

`JMPA` 编码：`1111_00aa_aaaaaaaa`，低 10 位为绝对地址。汇编器会拒绝跨页 `JUMP/JZ`，并提示使用本页 trampoline 与 `JMPA`。

## I/O 映射

| 地址 | 方向 | 功能 |
|---|---|---|
| `0x10` | R/W | CPU UART 数据 |
| `0x11` | R | UART 状态 |
| `0x12` | R | 游戏 Tick/读取确认 |
| `0x13` | R | LFSR 随机数 |
| `0x14` | R/W | 软件速度增量 `0..3` |
| `0x20` | R/W | 数码管低 4 位 |
| `0x21` | R/W | 数码管高 4 位 |
| `0x22` | R/W | 数码管控制 |
| `0x30` | R/W | LED |
| `0x31` | R | 同步后的拨码 |
| `0x32` | R | CPU Flags |
| `0x40..0x4F` | R/W | Scratchpad |

硬件速度等于 `SW1..0 + 软件速度增量`，饱和到 3；SW2 暂停；SW7 专用于 Loader/Run 模式。100 MHz 下四档移动间隔约为 `1.0 / 0.5 / 0.25 / 0.125 秒`，比初版整体慢一倍。

## 构建与验证

在本目录打开 PowerShell：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\scripts\run.ps1" -Task Assemble
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\scripts\run.ps1" -Task Regression
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\scripts\run.ps1" -Task CreateProject
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\scripts\run.ps1" -Task Bitstream
```

Vivado 默认位置为 `F:\vivado\2026.1\Vivado\bin`；其他安装位置可增加 `-VivadoBin`。

主要交付物：

- `vivado_project/MiniRISC16_Runtime.xpr`
- `reports/board/MiniRISC16_Runtime.bit`
- `program/snake.asm`、`snake.mem`、`snake.lst`
- `tools/upload_program.ps1`
- `tools/snake_terminal.ps1`

## 已验证结果

- 汇编：294 条有效指令，跨 Page 0/Page 1，剩余 730 字。
- 独立参考模型：PASS，执行 13964 条指令。
- XSim：6/6 PASS。
- 实现后时序：WNS `+0.157 ns`，TNS `0`；WHS `+0.049 ns`，THS `0`。
- 布线：0 条未布通网络；DRC 0 Error。
- 资源：1204 LUT、750 FF、44 IOB、程序 RAM 为 `1K×16` 分布式 RAM。
- bitstream SHA-256：`B0F2813099A7713DAD040DA765B50DF3B8DE8BBA3C6BAF7E2D49E1FF0DA15F71`。

实板步骤见 `BOARD_TEST_GUIDE.md`，问题与修复证据见 `BUG_FIX_LOG.md`。
