# Runtime System / Snake V2 上板测试

## 1. 接线

1. J3 连接电脑，用于 JTAG 下载。
2. J8 上方 PL UART USB 连接电脑；已安装 CP210x VCP 驱动后，本机识别为 COM3。
3. 板卡上电，启动拨码保持此前已验证的 `SW8=000000`。

J3 的 COM8 是 PS UART，不是本工程使用的 PL UART；终端和程序上传均使用 J8 对应的 COM3。

## 2. 下载 bitstream

bitstream：

```text
reports\board\MiniRISC16_Runtime.bit
```

在 Vivado Hardware Manager 中 Open Target、Auto Connect、Program Device，选择该 `.bit`。下载前建议令 SW7=0。

## 3. 直接运行内置 Snake V2

1. SW7=0。
2. 按下并松开 S1。
3. 在本目录运行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\tools\snake_terminal.ps1" -PortName COM3
```

控制：

- `W/A/S/D` 或方向键：移动。
- `R`：游戏重新开始。
- `Q`：退出终端。
- SW1..0：基础速度；`00/01/10/11` 对应约 `1.0/0.5/0.25/0.125 秒`，得分带来的软件加速会在此基础上提高档位。
- SW2：暂停。
- SW3..6：参与随机种子。
- SW7：0 为运行，1 为程序加载模式。

终端中的 `X` 是固定障碍物，`@` 是蛇头，`#` 是蛇身，`*` 是食物。每吃一个食物，软件速度等级增加并在 3 饱和；High 显示本次硬件复位以来的最高分。

## 4. 通过 UART 更换程序

加载时不要同时运行 Snake 终端，COM3 只能被一个程序占用。

1. 关闭 Snake 终端。
2. 将 SW7 置 1。CPU 被复位保持，数码管显示 `10AD`。
3. LED5 表示 Loader Busy，LED6 表示上传成功，LED7 表示校验或协议错误。
4. 上传默认 `program\snake.mem`：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\tools\upload_program.ps1" -PortName COM3
```

5. 看到 `UPLOAD PASS` 后，LED6 应点亮。
6. 将 SW7 置 0，CPU 从地址 `0x000` 执行刚上传的程序。
7. 再次启动 `snake_terminal.ps1`。

上传其他程序：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\tools\upload_program.ps1" -PortName COM3 -Program ".\program\other.mem"
```

上传内容在断电或重新下载 bitstream 前保持；S1 只复位 CPU/外设，不擦除已上传程序。重新配置 FPGA 后恢复 bitstream 内置的 Snake V2。

## 5. Snake V2 验收项目

1. 终端出现 8×8 棋盘和 4 个 `X` 障碍物。
2. 方向键能够控制，反方向输入被拒绝。
3. 撞墙、撞蛇身或撞障碍物均进入 GAME OVER。
4. 吃食物后长度、Score 和 Level 增加。
5. Score 增大后移动速度提升，SW1..0 仍可叠加基础速度。
6. 游戏结束后 High 更新；按 R 后 High 保留。
7. SW2 暂停期间不移动，解除后恢复。
8. S1 能在任意状态恢复初始游戏。
9. 执行一次 UART 上传，SW7 返回 0 后程序重新正常运行。

## 6. 常见问题

- 一直显示 `Waiting for frames`：确认 SW7=0、使用 COM3、J8 已连接且 CP2103 驱动正常。
- COM3 被占用：关闭另一个 PowerShell 串口脚本或串口助手。
- 数码管显示 `10AD`：当前 SW7=1，属于 Loader 模式。
- LED7 点亮：上传包长度/校验失败，保持 SW7=1 后重新运行上传脚本。
- 上传后无运行：确认出现 `UPLOAD PASS`，然后把 SW7 从 1 切回 0。
